public class Ders extends OgretimGorevlisi{
    String DersAdi;
    String DersKodu;
    String DersDonemi;
    String OgretimGorevlisi;
    String DersBolum;

    public String getDersAdi() {
        return DersAdi;
    }

    public void setDersAdi(String DersAdi) {
        this.DersAdi = DersAdi;
    }

    public String getDersKodu() {
        return DersKodu;
    }

    public void setDersKodu(String DersKodu) {
        this.DersKodu = DersKodu;
    }
    public String getDersDonemi() {
        return DersDonemi;
    }

    public void setDersDonemi(String DersDonemi) {
        this.DersDonemi = DersDonemi;
    }
    public String getOgretimGorevlisi() {
        return OgretimGorevlisi;
    }

    public void setOgretimGorevlisi(String OgretimGorevlisi) {
        this.OgretimGorevlisi = OgretimGorevlisi;
    }

    public String getDersBolum() {
        return DersBolum;
    }

    public void setDersBolum(String DersBolum) {
        this.DersBolum = DersBolum;
    }
}
