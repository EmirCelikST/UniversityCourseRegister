public class OgretimGorevlisi {
    String OgretimGorevlisiAdi;
    String OgretimGorevlisiSoyadi;
    String OgretimGorevlisiNo;
    String OgretimGorevlisiBolum;
    public String getOgretimGorevlisiAdi() {
        return OgretimGorevlisiAdi;
    }

    public void setOgretimGorevlisiAdi(String OgretimGorevlisiAdi) {
        this.OgretimGorevlisiAdi = OgretimGorevlisiAdi;
    }

    public String getOgretimGorevlisiSoyadi() {
        return OgretimGorevlisiSoyadi;
    }

    public void setOgretimGorevlisiSoyadi(String OgretimGorevlisiSoyadi) {
        this.OgretimGorevlisiSoyadi = OgretimGorevlisiSoyadi;
    }

    public String getOgretimGorevlisiNo() {
        return OgretimGorevlisiNo;
    }

    public void setOgretimGorevlisiNo(String OgretimGorevlisiNo) {
        this.OgretimGorevlisiNo = OgretimGorevlisiNo;
    }
    public String getOgretimGorevlisiBolum() {
        return OgretimGorevlisiBolum;
    }

    public void setOgretimGorevlisiBolum(String OgretimGorevlisiBolum) {
        this.OgretimGorevlisiBolum = OgretimGorevlisiBolum;
    }
}
