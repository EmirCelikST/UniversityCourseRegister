

public class Ogrenci extends Ders {
    String OgrenciAdi;
    String OgrenciSoyadi;
    String OgrenciNo;
    String OgrenciBolum;
    String OgrenciDonem;
    String OgrenciDersSecimi;



    public String getOgrenciAdi() {
        return OgrenciAdi;
    }

    public void setOgrenciAdi(String OgrenciAdi) {
        this.OgrenciAdi = OgrenciAdi;
    }

    public String getOgrenciSoyadi() {
        return OgrenciSoyadi;
    }

    public void setOgrenciSoyadi(String OgrenciSoyadi) {
        this.OgrenciSoyadi = OgrenciSoyadi;
    }

    public String getOgrenciNo() {
        return OgrenciNo;
    }

    public void setOgrenciNo(String OgrenciNo) {
        this.OgrenciNo = OgrenciNo;
    }
    public String getOgrenciBolum() {
        return OgrenciBolum;
    }

    public void setOgrenciBolum(String OgrenciBolum) {
        this.OgrenciBolum = OgrenciBolum;
    }

    public String getOgrenciDonem() {
        return OgrenciDonem;
    }

    public void setOgrenciDonem(String OgrenciDonem) {this.OgrenciDonem = OgrenciDonem;}


    public String getOgrenciDersSecimi() {
        return OgrenciDersSecimi;
    }

    public void setOgrenciDersSecimi(String OgrenciDersSecimi) {this.OgrenciDersSecimi = OgrenciDersSecimi;}


}
